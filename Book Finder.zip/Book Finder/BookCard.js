import React from "react";

const BookCard = ({ book }) => {
  return (
    <div className="p-4 bg-white rounded-lg shadow-md">
      <h2 className="text-xl font-semibold">{book.title || "Untitled"}</h2>
      <p className="text-gray-700">
        <strong>Author:</strong> {book.author_name ? book.author_name.join(", ") : "Unknown"}
      </p>
      <p className="text-gray-700">
        <strong>First Published:</strong> {book.first_publish_year || "N/A"}
      </p>
      <p className="text-gray-700">
        <strong>Publisher:</strong> {book.publisher ? book.publisher[0] : "N/A"}
      </p>
      <p className="text-gray-700">
        <strong>ISBN:</strong> {book.isbn ? book.isbn[0] : "N/A"}
      </p>
    </div>
  );
};

export default BookCard;
