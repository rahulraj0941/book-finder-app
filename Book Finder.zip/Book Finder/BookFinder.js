import React, { useState } from "react";
import BookCard from "./BookCard";

const BookFinder = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchBooks = async () => {
    if (!searchTerm) return;
    setLoading(true);
    setError(null);
    setBooks([]);

    try {
      const response = await fetch(
        `https://openlibrary.org/search.json?title=${encodeURIComponent(searchTerm)}`
      );
      if (!response.ok) throw new Error("Network response was not ok");
      const data = await response.json();
      
      if (data.numFound === 0) {
        setError("No books found for the given title.");
      } else {
        setBooks(data.docs);
      }
    } catch (err) {
      setError("An error occurred while fetching data.");
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    fetchBooks();
  };

  return (
    <div className="max-w-md mx-auto">
      <form onSubmit={handleSearch} className="flex mb-4">
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Enter book title"
          className="p-2 border border-gray-300 rounded-l-md flex-grow"
        />
        <button
          type="submit"
          className="p-2 bg-blue-500 text-white rounded-r-md"
          disabled={loading}
        >
          {loading ? "Searching..." : "Search"}
        </button>
      </form>

      {error && <div className="text-red-500 mb-4">{error}</div>}

      <div className="grid gap-4">
        {books.map((book) => (
          <BookCard key={book.key} book={book} />
        ))}
      </div>
    </div>
  );
};

export default BookFinder;
