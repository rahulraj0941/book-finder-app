import React from "react";
import BookFinder from "./components/BookFinder";

function App() {
  return (
    <div className="bg-gray-100 min-h-screen p-4">
      <h1 className="text-center text-3xl font-bold mb-8">Book Finder</h1>
      <BookFinder />
    </div>
  );
}

export default App;
